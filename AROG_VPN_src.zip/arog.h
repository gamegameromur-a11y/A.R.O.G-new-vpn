#pragma once
#include <windows.h>
#include <string>
#include <fstream>
#include <sstream>

// ─────────────────────────────────────────────────────────────────────────────
// Config dosya yolu
// ─────────────────────────────────────────────────────────────────────────────
#define AROG_CONFIG_DIR   "C:\\AROG"
#define AROG_CONFIG_PATH  "C:\\AROG\\arog.conf"
#define WG_EXE            "C:\\Program Files\\WireGuard\\wireguard.exe"
#define WG_EXE_X86       "C:\\Program Files (x86)\\WireGuard\\wireguard.exe"
#define TUNNEL_NAME       "arog"

// ─────────────────────────────────────────────────────────────────────────────
// Yardımcı: komut çalıştır, çıktı döndür
// ─────────────────────────────────────────────────────────────────────────────
static std::string runCommand(const std::string& cmd) {
    STARTUPINFOA si = { sizeof(si) };
    PROCESS_INFORMATION pi;
    si.dwFlags     = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    HANDLE hRead, hWrite;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    if (!CreatePipe(&hRead, &hWrite, &sa, 0)) return "";
    si.hStdOutput = hWrite;
    si.hStdError  = hWrite;

    char buf[4096] = {};
    std::string cmdCopy = cmd;
    if (CreateProcessA(NULL, &cmdCopy[0], NULL, NULL, TRUE,
        CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        CloseHandle(hWrite);
        DWORD bytes;
        ReadFile(hRead, buf, sizeof(buf) - 1, &bytes, NULL);
        WaitForSingleObject(pi.hProcess, 10000);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    } else {
        CloseHandle(hWrite);
    }
    CloseHandle(hRead);
    return std::string(buf);
}

// ─────────────────────────────────────────────────────────────────────────────
// ArogVPN sınıfı
// ─────────────────────────────────────────────────────────────────────────────
class ArogVPN {
public:
    std::string serverIP;
    std::string serverPublicKey;
    std::string clientPrivateKey;
    std::string clientPublicKey;
    std::string clientAddress;  // örn: 10.8.0.2
    std::string dnsServer;

    ArogVPN() {
        dnsServer    = "1.1.1.1";
        clientAddress = "10.8.0.2";
    }

    // Config dosyasını yükle (varsa)
    bool loadConfig() {
        std::ifstream f(AROG_CONFIG_PATH);
        if (!f.is_open()) return false;

        std::string line;
        while (std::getline(f, line)) {
            auto parse = [&](const std::string& key, std::string& out) {
                if (line.find(key + " = ") == 0)
                    out = line.substr(key.size() + 3);
            };
            parse("PrivateKey",   clientPrivateKey);
            parse("Address",      clientAddress);
            parse("DNS",          dnsServer);
            parse("PublicKey",    serverPublicKey);
            parse("Endpoint",     serverIP);  // "IP:port" formatında gelir
        }

        // Endpoint'ten sadece IP kısmını al
        auto colon = serverIP.find(':');
        if (colon != std::string::npos)
            serverIP = serverIP.substr(0, colon);

        return !clientPrivateKey.empty();
    }

    // Config dosyasını oluştur/güncelle
    bool writeConfig() {
        CreateDirectoryA(AROG_CONFIG_DIR, NULL);

        std::ofstream f(AROG_CONFIG_PATH);
        if (!f.is_open()) return false;

        f << "[Interface]\n";
        f << "PrivateKey = " << clientPrivateKey << "\n";
        f << "Address = " << clientAddress << "/24\n";
        f << "DNS = " << dnsServer << "\n";
        f << "MTU = 1420\n\n";

        f << "[Peer]\n";
        f << "PublicKey = " << serverPublicKey << "\n";
        f << "Endpoint = " << serverIP << ":51820\n";
        f << "AllowedIPs = 0.0.0.0/0\n";
        f << "PersistentKeepalive = 25\n";

        return true;
    }

    // WireGuard yüklü mü?
    bool isWireGuardInstalled() {
        return (GetFileAttributesA(WG_EXE) != INVALID_FILE_ATTRIBUTES ||
                GetFileAttributesA(WG_EXE_X86) != INVALID_FILE_ATTRIBUTES);
    }

    std::string getWgExe() {
        if (GetFileAttributesA(WG_EXE) != INVALID_FILE_ATTRIBUTES)
            return std::string(WG_EXE);
        return std::string(WG_EXE_X86);
    }

    // Bağlan
    bool connect() {
        if (!isWireGuardInstalled()) {
            MessageBoxA(NULL,
                "WireGuard yüklü değil!\nhttps://www.wireguard.com/install/ adresinden indirin.",
                "AROG VPN", MB_OK | MB_ICONERROR);
            return false;
        }
        if (!writeConfig()) return false;

        std::string wg = getWgExe();
        std::string cmd = "\"" + wg + "\" /installtunnelservice \"" + AROG_CONFIG_PATH + "\"";

        // Önce var olan tunnel'ı kaldır
        std::string rmCmd = "\"" + wg + "\" /uninstalltunnelservice " + TUNNEL_NAME;
        runCommand(rmCmd);
        Sleep(1000);

        runCommand(cmd);
        Sleep(2000);

        return isTunnelActive();
    }

    // Bağlantıyı kes
    void disconnect() {
        std::string wg = getWgExe();
        std::string cmd = "\"" + wg + "\" /uninstalltunnelservice " + TUNNEL_NAME;
        runCommand(cmd);
    }

    // Tunnel aktif mi?
    bool isTunnelActive() {
        std::string out = runCommand("sc query WireGuardTunnel$arog");
        return out.find("RUNNING") != std::string::npos;
    }

    // Dış IP'yi al
    std::string getExternalIP() {
        // curl ile api4.my-ip.io'dan al
        std::string out = runCommand("curl -s --max-time 5 https://api4.my-ip.io/ip");
        if (out.empty() || out.size() > 40) return "Bilinmiyor";
        // Satır sonu temizle
        while (!out.empty() && (out.back() == '\n' || out.back() == '\r'))
            out.pop_back();
        return out;
    }
};
