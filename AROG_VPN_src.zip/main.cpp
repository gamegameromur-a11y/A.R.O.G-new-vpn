#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "arog.h"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(linker, "/subsystem:windows")

// ── ID'ler ──────────────────────────────────────────────────────────────────
#define ID_BTN_CONNECT    101
#define ID_BTN_DISCONNECT 102
#define ID_LABEL_STATUS   103
#define ID_LABEL_IP       104
#define ID_LABEL_PING     105
#define ID_TIMER_PING     201

// ── Global ──────────────────────────────────────────────────────────────────
HWND g_hWnd         = NULL;
HWND g_hBtnConnect  = NULL;
HWND g_hBtnDisconn  = NULL;
HWND g_hLblStatus   = NULL;
HWND g_hLblIP       = NULL;
HWND g_hLblPing     = NULL;
HFONT g_hFontTitle  = NULL;
HFONT g_hFontBody   = NULL;
HFONT g_hFontSmall  = NULL;
bool  g_connected   = false;
ArogVPN* g_vpn      = nullptr;

// ── Renkler ─────────────────────────────────────────────────────────────────
#define CLR_BG        RGB(10,  12,  20)
#define CLR_PANEL     RGB(18,  22,  35)
#define CLR_ACCENT    RGB(0,   200, 150)
#define CLR_ACCENT2   RGB(0,   150, 255)
#define CLR_TEXT      RGB(220, 230, 255)
#define CLR_SUBTEXT   RGB(100, 120, 160)
#define CLR_BTN_CON   RGB(0,   180, 120)
#define CLR_BTN_DIS   RGB(200, 50,  80)
#define CLR_BTN_HOV   RGB(0,   220, 160)

// ── Yardımcı ─────────────────────────────────────────────────────────────────
std::wstring s2w(const std::string& s) {
    if (s.empty()) return L"";
    int sz = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, NULL, 0);
    std::wstring w(sz, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], sz);
    return w;
}

std::string getPing() {
    // ping komutu çalıştır, ms değeri döndür
    STARTUPINFOA si = {sizeof(si)};
    PROCESS_INFORMATION pi;
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    HANDLE hRead, hWrite;
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    CreatePipe(&hRead, &hWrite, &sa, 0);
    si.hStdOutput = hWrite;
    si.hStdError  = hWrite;

    char cmd[] = "ping -n 1 8.8.8.8";
    if (!CreateProcessA(NULL, cmd, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi)) {
        CloseHandle(hRead); CloseHandle(hWrite);
        return "-- ms";
    }
    CloseHandle(hWrite);
    WaitForSingleObject(pi.hProcess, 3000);

    char buf[512] = {};
    DWORD bytesRead;
    ReadFile(hRead, buf, sizeof(buf)-1, &bytesRead, NULL);
    CloseHandle(hRead);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    std::string out(buf);
    auto pos = out.find("time=");
    if (pos == std::string::npos) pos = out.find("sre=");
    if (pos != std::string::npos) {
        auto end = out.find("ms", pos);
        if (end != std::string::npos) {
            auto val = out.substr(pos + 5, end - pos - 5);
            return val + " ms";
        }
    }
    return "-- ms";
}

// ── Custom Button çiz ────────────────────────────────────────────────────────
LRESULT CALLBACK BtnConnProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP, UINT_PTR, DWORD_PTR) {
    static bool hover = false;
    switch (msg) {
        case WM_MOUSEMOVE: hover = true; InvalidateRect(hWnd, NULL, TRUE); break;
        case WM_MOUSELEAVE: hover = false; InvalidateRect(hWnd, NULL, TRUE); break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            RECT rc; GetClientRect(hWnd, &rc);
            COLORREF bg = hover ? CLR_BTN_HOV : CLR_BTN_CON;
            HBRUSH br = CreateSolidBrush(bg);
            HPEN pen = CreatePen(PS_SOLID, 0, bg);
            SelectObject(hdc, br); SelectObject(hdc, pen);
            RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, 12, 12);
            DeleteObject(br); DeleteObject(pen);
            SetBkMode(hdc, TRANSPARENT);
            SetTextColor(hdc, RGB(10, 12, 20));
            SelectObject(hdc, g_hFontBody);
            DrawTextW(hdc, L"BAĞLAN", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            EndPaint(hWnd, &ps);
            return 0;
        }
    }
    return DefSubclassProc(hWnd, msg, wP, lP);
}

LRESULT CALLBACK BtnDiscProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP, UINT_PTR, DWORD_PTR) {
    static bool hover = false;
    switch (msg) {
        case WM_MOUSEMOVE: hover = true; InvalidateRect(hWnd, NULL, TRUE); break;
        case WM_MOUSELEAVE: hover = false; InvalidateRect(hWnd, NULL, TRUE); break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            RECT rc; GetClientRect(hWnd, &rc);
            COLORREF bg = hover ? RGB(220, 70, 100) : CLR_BTN_DIS;
            HBRUSH br = CreateSolidBrush(bg);
            HPEN pen = CreatePen(PS_SOLID, 0, bg);
            SelectObject(hdc, br); SelectObject(hdc, pen);
            RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, 12, 12);
            DeleteObject(br); DeleteObject(pen);
            SetBkMode(hdc, TRANSPARENT);
            SetTextColor(hdc, RGB(255, 255, 255));
            SelectObject(hdc, g_hFontBody);
            DrawTextW(hdc, L"KES", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            EndPaint(hWnd, &ps);
            return 0;
        }
    }
    return DefSubclassProc(hWnd, msg, wP, lP);
}

// ── WndProc ──────────────────────────────────────────────────────────────────
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP) {
    switch (msg) {

    case WM_CREATE: {
        // Fontlar
        g_hFontTitle = CreateFontW(28, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        g_hFontBody = CreateFontW(16, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        g_hFontSmall = CreateFontW(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");

        // Status label
        g_hLblStatus = CreateWindowW(L"STATIC", L"● BAĞLI DEĞİL",
            WS_CHILD | WS_VISIBLE | SS_CENTER,
            60, 130, 280, 30, hWnd, (HMENU)ID_LABEL_STATUS, NULL, NULL);
        SendMessage(g_hLblStatus, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);

        // IP label
        g_hLblIP = CreateWindowW(L"STATIC", L"IP: ---.---.---.---",
            WS_CHILD | WS_VISIBLE | SS_CENTER,
            60, 170, 280, 22, hWnd, (HMENU)ID_LABEL_IP, NULL, NULL);
        SendMessage(g_hLblIP, WM_SETFONT, (WPARAM)g_hFontSmall, TRUE);

        // Ping label
        g_hLblPing = CreateWindowW(L"STATIC", L"Ping: -- ms",
            WS_CHILD | WS_VISIBLE | SS_CENTER,
            60, 192, 280, 22, hWnd, (HMENU)ID_LABEL_PING, NULL, NULL);
        SendMessage(g_hLblPing, WM_SETFONT, (WPARAM)g_hFontSmall, TRUE);

        // Butonlar
        g_hBtnConnect = CreateWindowW(L"BUTTON", L"BAĞLAN",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            60, 240, 130, 44, hWnd, (HMENU)ID_BTN_CONNECT, NULL, NULL);
        SendMessage(g_hBtnConnect, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SetWindowSubclass(g_hBtnConnect, BtnConnProc, 0, 0);

        g_hBtnDisconn = CreateWindowW(L"BUTTON", L"KES",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            210, 240, 130, 44, hWnd, (HMENU)ID_BTN_DISCONNECT, NULL, NULL);
        SendMessage(g_hBtnDisconn, WM_SETFONT, (WPARAM)g_hFontBody, TRUE);
        SetWindowSubclass(g_hBtnDisconn, BtnDiscProc, 0, 0);

        // Config yükle
        g_vpn = new ArogVPN();
        g_vpn->loadConfig();

        SetTimer(hWnd, ID_TIMER_PING, 5000, NULL);
        break;
    }

    case WM_TIMER: {
        if (wP == ID_TIMER_PING && g_connected) {
            std::string ping = getPing();
            SetWindowTextW(g_hLblPing, (L"Ping: " + s2w(ping)).c_str());
        }
        break;
    }

    case WM_COMMAND: {
        if (LOWORD(wP) == ID_BTN_CONNECT && !g_connected) {
            SetWindowTextW(g_hLblStatus, L"◌ BAĞLANIYOR...");
            InvalidateRect(hWnd, NULL, FALSE);
            UpdateWindow(hWnd);

            if (g_vpn->connect()) {
                g_connected = true;
                SetWindowTextW(g_hLblStatus, L"● BAĞLANDI");
                std::string ip = g_vpn->getExternalIP();
                SetWindowTextW(g_hLblIP, (L"IP: " + s2w(ip)).c_str());
                std::string ping = getPing();
                SetWindowTextW(g_hLblPing, (L"Ping: " + s2w(ping)).c_str());
            } else {
                SetWindowTextW(g_hLblStatus, L"✕ BAĞLANTI HATASI");
                MessageBoxW(hWnd, L"Bağlantı kurulamadı!\nWireGuard yüklü mü?\nConfig dosyası doğru mu?",
                    L"AROG VPN Hata", MB_OK | MB_ICONERROR);
            }
            InvalidateRect(hWnd, NULL, FALSE);
        }
        else if (LOWORD(wP) == ID_BTN_DISCONNECT && g_connected) {
            g_vpn->disconnect();
            g_connected = false;
            SetWindowTextW(g_hLblStatus, L"● BAĞLI DEĞİL");
            SetWindowTextW(g_hLblIP,     L"IP: ---.---.---.---");
            SetWindowTextW(g_hLblPing,   L"Ping: -- ms");
            InvalidateRect(hWnd, NULL, FALSE);
        }
        break;
    }

    case WM_CTLCOLORSTATIC: {
        HDC hdc = (HDC)wP;
        SetBkMode(hdc, TRANSPARENT);
        HWND ctrl = (HWND)lP;
        if (ctrl == g_hLblStatus) {
            SetTextColor(hdc, g_connected ? CLR_ACCENT : CLR_SUBTEXT);
        } else {
            SetTextColor(hdc, CLR_SUBTEXT);
        }
        return (LRESULT)CreateSolidBrush(CLR_PANEL);
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        RECT rc; GetClientRect(hWnd, &rc);

        // Arka plan
        HBRUSH bgBrush = CreateSolidBrush(CLR_BG);
        FillRect(hdc, &rc, bgBrush);
        DeleteObject(bgBrush);

        // Panel
        RECT panel = {20, 20, 380, 310};
        HBRUSH panelBrush = CreateSolidBrush(CLR_PANEL);
        HPEN panelPen = CreatePen(PS_SOLID, 1, RGB(30, 40, 60));
        SelectObject(hdc, panelBrush);
        SelectObject(hdc, panelPen);
        RoundRect(hdc, panel.left, panel.top, panel.right, panel.bottom, 16, 16);
        DeleteObject(panelBrush);
        DeleteObject(panelPen);

        // Accent çizgi (üst)
        HPEN accentPen = CreatePen(PS_SOLID, 2, CLR_ACCENT);
        SelectObject(hdc, accentPen);
        MoveToEx(hdc, 40, 21, NULL);
        LineTo(hdc, 180, 21);
        DeleteObject(accentPen);

        // Logo / Başlık
        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, CLR_TEXT);
        SelectObject(hdc, g_hFontTitle);
        RECT titleRc = {20, 40, 380, 80};
        DrawTextW(hdc, L"A.R.O.G VPN", -1, &titleRc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        // Alt yazı
        SetTextColor(hdc, CLR_SUBTEXT);
        SelectObject(hdc, g_hFontSmall);
        RECT subRc = {20, 78, 380, 100};
        DrawTextW(hdc, L"Güvenli · Hızlı · Güvenilir", -1, &subRc, DT_CENTER | DT_SINGLELINE);

        // Ayırıcı
        HPEN sepPen = CreatePen(PS_SOLID, 1, RGB(30, 40, 60));
        SelectObject(hdc, sepPen);
        MoveToEx(hdc, 40, 115, NULL);
        LineTo(hdc, 360, 115);
        DeleteObject(sepPen);

        // Versiyon
        SetTextColor(hdc, RGB(50, 60, 90));
        SelectObject(hdc, g_hFontSmall);
        RECT verRc = {20, 320, 380, 340};
        DrawTextW(hdc, L"v1.0.0  |  AROG VPN", -1, &verRc, DT_CENTER | DT_SINGLELINE);

        EndPaint(hWnd, &ps);
        return 0;
    }

    case WM_DESTROY:
        KillTimer(hWnd, ID_TIMER_PING);
        if (g_vpn) { delete g_vpn; g_vpn = nullptr; }
        DeleteObject(g_hFontTitle);
        DeleteObject(g_hFontBody);
        DeleteObject(g_hFontSmall);
        PostQuitMessage(0);
        break;
    }
    return DefWindowProcW(hWnd, msg, wP, lP);
}

// ── WinMain ──────────────────────────────────────────────────────────────────
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {
    InitCommonControls();

    WNDCLASSEXW wc = {};
    wc.cbSize        = sizeof(wc);
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(CLR_BG);
    wc.lpszClassName = L"ArogVPN";
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    RegisterClassExW(&wc);

    int W = 400, H = 360;
    int sx = GetSystemMetrics(SM_CXSCREEN);
    int sy = GetSystemMetrics(SM_CYSCREEN);

    g_hWnd = CreateWindowExW(
        WS_EX_APPWINDOW,
        L"ArogVPN", L"A.R.O.G VPN",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        (sx - W) / 2, (sy - H) / 2, W, H,
        NULL, NULL, hInst, NULL
    );

    ShowWindow(g_hWnd, nCmdShow);
    UpdateWindow(g_hWnd);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}
