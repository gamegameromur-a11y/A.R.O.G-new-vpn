#pragma once

// Dialog ID'leri
#define IDD_SETUP       100

// Control ID'leri (setup.h ile eşleşmeli)
#define ID_SETUP_IP       301
#define ID_SETUP_PUBKEY   302
#define ID_SETUP_PRIVKEY  303
#define ID_SETUP_OK       304
#define ID_SETUP_CANCEL   305

// Static kontroller için
#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif
