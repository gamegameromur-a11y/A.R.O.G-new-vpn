#pragma once
#include <windows.h>
#include <string>
#include "arog.h"

// ID'ler
#define ID_SETUP_IP       301
#define ID_SETUP_PUBKEY   302
#define ID_SETUP_PRIVKEY  303
#define ID_SETUP_OK       304
#define ID_SETUP_CANCEL   305
#define ID_SETUP_GENLBL   306

// Font
static HFONT g_hSetupFont = NULL;

// Editbox'lardan değer al
static std::string getEditText(HWND hDlg, int id) {
    char buf[512] = {};
    GetDlgItemTextA(hDlg, id, buf, sizeof(buf));
    return std::string(buf);
}

// Setup dialog proc
static INT_PTR CALLBACK SetupDlgProc(HWND hDlg, UINT msg, WPARAM wP, LPARAM lP) {
    switch (msg) {
    case WM_INITDIALOG: {
        g_hSetupFont = CreateFontA(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, "Segoe UI");

        // Mevcut config varsa doldur
        ArogVPN* vpn = (ArogVPN*)lP;
        if (vpn && !vpn->serverIP.empty())
            SetDlgItemTextA(hDlg, ID_SETUP_IP, vpn->serverIP.c_str());
        if (vpn && !vpn->serverPublicKey.empty())
            SetDlgItemTextA(hDlg, ID_SETUP_PUBKEY, vpn->serverPublicKey.c_str());
        if (vpn && !vpn->clientPrivateKey.empty())
            SetDlgItemTextA(hDlg, ID_SETUP_PRIVKEY, vpn->clientPrivateKey.c_str());

        return TRUE;
    }

    case WM_CTLCOLORDLG: {
        return (LRESULT)CreateSolidBrush(RGB(15, 18, 28));
    }

    case WM_CTLCOLORSTATIC: {
        HDC hdc = (HDC)wP;
        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, RGB(180, 200, 255));
        return (LRESULT)CreateSolidBrush(RGB(15, 18, 28));
    }

    case WM_CTLCOLOREDIT: {
        HDC hdc = (HDC)wP;
        SetBkColor(hdc, RGB(25, 30, 50));
        SetTextColor(hdc, RGB(220, 230, 255));
        return (LRESULT)CreateSolidBrush(RGB(25, 30, 50));
    }

    case WM_COMMAND: {
        if (LOWORD(wP) == ID_SETUP_OK) {
            ArogVPN* vpn = (ArogVPN*)GetWindowLongPtr(hDlg, DWLP_USER);
            // Dialog data pointer'ı al
            // Setup result'ı geri döndür
            std::string ip      = getEditText(hDlg, ID_SETUP_IP);
            std::string pubkey  = getEditText(hDlg, ID_SETUP_PUBKEY);
            std::string privkey = getEditText(hDlg, ID_SETUP_PRIVKEY);

            if (ip.empty() || pubkey.empty() || privkey.empty()) {
                MessageBoxA(hDlg, "Tüm alanları doldurun!", "AROG VPN", MB_OK | MB_ICONWARNING);
                return TRUE;
            }

            // Sonucu lParam olarak kaydet
            struct SetupResult* res = (struct SetupResult*)GetWindowLongPtrA(hDlg, GWLP_USERDATA);
            if (res) {
                res->ip      = ip;
                res->pubkey  = pubkey;
                res->privkey = privkey;
            }

            EndDialog(hDlg, IDOK);
            return TRUE;
        }
        if (LOWORD(wP) == ID_SETUP_CANCEL) {
            EndDialog(hDlg, IDCANCEL);
            return TRUE;
        }
        break;
    }

    case WM_DESTROY:
        if (g_hSetupFont) { DeleteObject(g_hSetupFont); g_hSetupFont = NULL; }
        break;
    }
    return FALSE;
}

// Setup result struct
struct SetupResult {
    std::string ip;
    std::string pubkey;
    std::string privkey;
};
